class DailyDigestEmail:

    def __init__(self):
        pass

    def send_email(self):
        pass

    def format_message(self):
        pass

if __name__ == '__main__':
    pass # test code